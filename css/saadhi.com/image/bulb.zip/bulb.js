// Turn on function

function bulbOn(){
    let bulbobj = document.querySelector(".bulboff");
    bulbobj.setAttribute("src","./on bulb.png");
}

// Turn off function

function bulbOff(){
    let bulbobj = document.querySelector(".bulboff");
    bulbobj.setAttribute("src","./off bulb.png");
}